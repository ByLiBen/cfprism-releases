CFBest Sub GUI - Offline Package

1. Extract the whole ZIP before running the program.
2. Double-click cfbest-sub-gui.exe.
3. bin\CloudflareST.exe is included for the normal speed test.
4. bin\mihomo.exe is included for the optional second-stage test.
5. Keep configs, ips, bin, and the main executable together.

Windows 10/11 normally includes WebView2. If the window cannot open, install Microsoft WebView2 Runtime.
